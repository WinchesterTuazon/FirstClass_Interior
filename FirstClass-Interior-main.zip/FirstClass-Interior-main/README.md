# Project First Class Interior

In this project we are working in different roles on a team to complete a website.
We each have different tasks to complete to finish the project.

The purpose of this project is to prepare us for how projects are done in the workspace.
This will show us how each of the roles in a team work together to complete a project.



Project Manager - Jack <br/>
Developer - Aakesh <br/>
Designer - Nate <br/>
Tester - Winchester
